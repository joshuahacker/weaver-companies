Thank you for downloading our NetSuite Sticky Header solution.

Refer to this YouTube video for the installation steps: https://youtu.be/zRiabCDwvkE

Enjoy!