/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

define(['N/url'], function(url) {

    function pageInit() {
        console.log('Page Initialized');

        // search/submit button
        document.getElementById('custpage_applyFilter').addEventListener('click', applyFilter);

        // session storage to remember view method
        var lastSelected = localStorage.getItem('custpage_options'); 
        if (lastSelected) {
            document.getElementById('custpage_options').value = lastSelected;
        }

        // page loader
        document.getElementById('loadingIndicator').style.display = 'block';

        window.onload = function() {
        // Hide the loading indicator once everything is loaded
        document.getElementById('loadingIndicator').style.display = 'none';
};

    }

   function applyFilter() {
      // block NS native "are you sure to want to leave this page?" message
      if (window.onbeforeunload){window.onbeforeunload=function() { null;};};
  
      // initiate params
        var dateFrom = document.getElementById('custpage_date_from').value;
        var dateTo = document.getElementById('custpage_date_to').value;
        var filterOptions = document.getElementById('custpage_options').value;

      // view method set
        localStorage.setItem('custpage_options', filterOptions); 
      
      // set params and reload page
        if (dateFrom && dateTo && dateFrom !== '' && dateTo !== '' !== 'viewby') {

            var params = {
                custpage_options: filterOptions,
                custpage_from_date: dateFrom,
                custpage_to_date: dateTo
            };

            var suiteletURL = url.resolveScript({
                scriptId: 'customscript_ss_pl_scis_sales_datatables',
                deploymentId: 'customdeploy_ss_pl_scis_sales_datatables'
            });

            suiteletURL += '&' + Object.keys(params).map(function(key) {
                return encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
            }).join('&');

            window.location.href = suiteletURL;
        } else {
            alert('Please select a valid date range.');
        }
    }

    return {
        pageInit: pageInit
    };
});
